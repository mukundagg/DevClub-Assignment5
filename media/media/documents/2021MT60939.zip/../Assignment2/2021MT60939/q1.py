a = int(input("a = "));
b = int(input("b = "));

print("a + b = " + str(a + b));
print("a - b = " + str(a - b));
print("a * b = " + str(a * b));
print("a / b = " + str(a / b));
print("a % b = " + str(a % b));
