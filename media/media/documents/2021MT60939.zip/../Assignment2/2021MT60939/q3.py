sgpa, credits = 0.0, 0;

for i in range(0, 5):
	c = int(input());
	sgpa += int(input()) * c;
	credits += c;
	
sgpa /= credits;
print(sgpa);
