import math

radius = int(input("radius = "));
sq1 = int(input("sq. side = "));
rect1 = int(input("rect. length = "));
rect2 = int(input("rect. readth = "));
plgm1 = int(input("||gm base = "));
plgm2 = int(input("||gm height = "));
trap1 = int(input("trap. l1 = "));
trap2 = int(input("trap. l2 = "));
trap3 = int(input("trap. h = "));

print("Circle area = " + str(3.14 * (math.pow(radius, 2))))
print("Square area = " + str(math.pow(sq1, 2)))
print("Rectangle area = " + str(rect1 * rect2))
print("||gram area = " + str(plgm1 * plgm2))
print("Trapezium area = " + str(((trap1 + trap2) / 2) * trap3))
